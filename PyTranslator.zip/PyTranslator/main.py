# Imports

from googletrans import Translator
import time

# Welcome Text

print("""__________        ___________                           .__          __                
\______   \___.__.\__    ___/___________    ____   _____|  | _____ _/  |_  ___________ 
 |     ___<   |  |  |    |  \_  __ \__  \  /    \ /  ___/  | \__  //   __\/  _ \_  __ /
 |    |    \___  |  |    |   |  | \// __ \|   |  //___ \|  |__/ __ \|  | (  <_> )  | \/
 |____|    / ____|  |____|   |__|  (____  /___|  /____  >____(____  /__|  \____/|__|   
           \/                           \/     \/     \/          \/                   """)

print("\nWelcome to PyTranslator!")

print("\nYou can use this app to translate from a language to an other language.")

time.sleep(1)

print("\nPyAssistant is starting...")
time.sleep(1)

print("Connecting to the server...")
time.sleep(5)

print("Almost Ready...")
time.sleep(3)

# Translation Process

try:
    # translation_input = str("Enter your translation text: ")
    # to_translate = str("Enter the language that you want to translate to: ")

    translator = Translator()

    translated_output = translator.translate("Hello World!", dest="ja")

    print("\nTranslated Text: '"+translated_output.text+"'")

except:

    print("\nAn Unknown Error has Occured!")